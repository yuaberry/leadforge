# LEADFORGE — Progresso de Execução

Cada fase só é marcada como concluída após `bun run verify` verde (typecheck + lint + test + build).

| Fase | Escopo | Status |
|---|---|---|
| 0 — Bootstrap | Next 15 + TS + Tailwind + shadcn clássico + Drizzle + Supabase client + env + Vitest + landing + auth + dashboard placeholder | ✅ Concluída |
| 1 — Tenancy & Auth | Orgs, membros, RBAC, RLS geral (todas as queries via withTenantDb sob `role=authenticated`), invites com link, onboarding do negócio digital, shell com sidebar/topbar, dashboard com dados reais | ✅ Concluída |
| 2 — Leads Core + Captura | Schema companies/contacts/leads/tags/activities/sources, normalização + dedup (4 chaves + índices únicos), CSV import com proveniência (upload→mapeamento→chunks), páginas públicas `/p/[slug]` com consent LGPD, listas com filtros/paginação, perfil do lead | ✅ Concluída |
| 3 — Product Hub + Commerce | Produtos (own/affiliate × plataformas), integrações com webhook token por org, webhooks Kiwify/Kirvano idempotentes, `/go/[token]` com clique+UTM, vendas manuais, dashboard com comissões | ✅ Concluída |
| 4 — Scoring + IA | Score weights editáveis, engine determinístico (score de nascimento), AIProvider (OpenRouter + mock), análise fatos/inferências/hipóteses, product match, message generator com link rastreado por lead | ✅ Concluída |
| 5 — CRM + Lucro + Metas | Pipeline kanban drag&drop, deals, tarefas, Profit Dashboard (receitas automáticas − despesas + gráficos), Metas gamificadas com alocação automática de % da comissão | ✅ Concluída |
| 6 — E-mail + Campanhas | EmailProvider (Resend+mock), Campaign Builder com steps/waits/caps/janela horária, modo manual com aprovação, suppression list + unsubscribe HMAC + webhook de bounce/complaint, cron | ✅ Concluída |
| 7 — WhatsApp + Inbox | WhatsAppCloudProvider, webhooks, opt-out, inbox unificada | ⬜ Próxima |
| 8 — Discovery | GooglePlacesProvider, busca avançada, pipeline de jobs | ⬜ |
| 9 — Analytics + Billing + Hardening | Analytics de conversão, Stripe prep, LGPD export/delete, audit, docs finais | ⬜ |

## Registro de gates

| Data | Fase | Gate | Observações |
|---|---|---|---|
| 2026-10-13 | 0 | verify ✅ | shadcn registry novo incompatível c/ Tailwind 3.4 (Node 18) — normalizado para Radix clássico. Vitest 5 exige Node 20+ — pinado em vitest@2.1.9. /dashboard marcado como force-dynamic. |
| 2026-10-13 | 1 | verify ✅ | Suíte RLS (10 testes) fica **dormante** até DATABASE_URL existir (skipIf) — ativa sozinha após `bun run db:migrate`. Mecanismo de query: withTenantDb (SET LOCAL ROLE authenticated + claims JWT) — RLS efetiva até para bugs de repository. Convites owner bloqueados na própria policy (anti-escalada). Sem FK users→auth.users para permitir testes com claims sintéticas (trigger garante integridade). |
| 2026-10-13 | 2 | verify ✅ | Gate E2E (formulário público cria lead consentido sem duplicar) coberto pela suíte RLS dormante (dedup por índice único + isolamento) + testes puros de normalização/CSV rodando (19 novos). Import executa em chunks resumíveis de 50 linhas (latência de rede); migra para fila na F6. Captura pública usa serviceDb DOCUMENTADO (anon não tem path de escrita no banco) + zod + honeypot + rate limit in-process (upgrade p/ Postgres na F6). |
| 2026-10-13 | 3 | verify ✅ | Gate (webhook simulado → sale + atribuição + idempotência + refund) coberto na suíte RLS dormante. Parsers Kiwify/Kirvano são tolerantes por aliases — **fixtures de teste precisam ser validados contra payloads reais ao conectar a conta** (TODO de integração). Roteamento de webhook por token único por org (multi-tenant); ingest em serviceDb com escopo manual por organization_id (RLS bypassada — revisada). /go/[token] loga clique + redireciona com UTMs lf_*. |
| 2026-10-14 | 4 | verify ✅ | Gate (unit tests determinísticos de scoring + IA mockada) — 62 testes. IA entra como SINAL no score (nunca pontua direto); recommended_product_id validado contra o catálogo real (IA não inventa ids). OpenRouter com json_mode + retry sem response_format; extractJson tolerante a fences. Mensagens nascem com link rastreado por lead (token reutilizado). Sem OPENROUTER_API_KEY, o MockProvider gera análise determinística honesta — UI indica "modo demonstração". |
| 2026-10-14 | 5 | verify ✅ | Gate (venda paga do webhook alimenta lucro + meta, idempotente na reentrega, celebra ao atingir) coberto na suíte RLS dormente (14 testes). Financeiro reconciliado com o status da venda (refund remove a receita auto). Kanban com drag&drop nativo + setas (acessível/mobile). Receita = sales (autoritativa dos webhooks) + manual; deals = forecast de CRM. |
| 2026-10-14 | 6 | verify ✅ | Gate (contato suprimido nunca recebe; opt-out exclui de campanhas futuras) provado em DOIS níveis: função pura decideEligibility (13 testes unitários) + teste de integração na suíte dormente (campanha automatizada com lead elegível + lead suprimido → 1 enviado, 1 excluído, 0 mensagens para o suprimido). Modo MANUAL nunca envia sozinho (pending_approval). Rodapé + header List-Unsubscribe em todo e-mail. Cron protegido por CRON_SECRET. Sem RESEND_API_KEY, envios são simulados e marcados como mock. |
